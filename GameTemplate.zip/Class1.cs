﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using PikaGames.Games.Core;

namespace $safeprojectname$
{
    public class Class1 : GameBase
    {

        protected override void Initialize()
        {
            base.Initialize();
        }
    }
}
